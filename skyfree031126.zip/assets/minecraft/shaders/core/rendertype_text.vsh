#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_001e31c0(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_05c77359() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_264ed626(inout vec4 vertex) {
    f_001e31c0(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_05c77359();
    }
    finalize();
}



void f_90945533() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_b18623a3() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c6e853ab(inout vec4 vertex) {
    f_001e31c0(vertex);
    f_90945533();
    finalize();
}

void f_87d94da3(inout vec4 vertex) {
    f_001e31c0(vertex);
    f_05c77359();
    f_b18623a3();
    finalize();
}

void f_ec97e126(inout vec4 vertex) {
    f_001e31c0(vertex);
    f_b18623a3();
    f_90945533();
    finalize();
}

void f_375a00d6(inout vec4 vertex) {
    f_05c77359();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_001e31c0(vertex);
    finalize();
}

void f_16b1dbd2(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_90945533();
    f_001e31c0(vertex);
    finalize();
}

void f_8305d2fe(inout vec4 vertex, float speed) {
    f_001e31c0(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_571c8f9a(inout vec4 vertex) {
    f_001e31c0(vertex);
    f_05c77359();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_264ed626(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_05c77359();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_001e31c0(vertex);
            f_05c77359();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_87d94da3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_87d94da3(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_375a00d6(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_375a00d6(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_8305d2fe(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_571c8f9a(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c6e853ab(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_87d94da3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_ec97e126(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_375a00d6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_16b1dbd2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_8305d2fe(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c6e853ab(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_87d94da3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_ec97e126(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_375a00d6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_16b1dbd2(vertex);
        return;
    }
    

    
    f_001e31c0(vertex);
    f_05c77359();
    finalize();
}