#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_bdc8ba8c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_a298389e() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_eae0bc66(inout vec4 vertex) {
    f_bdc8ba8c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_a298389e();
    }
    finalize();
}



void f_70211597() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_ae8b8804() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_d51aec5f(inout vec4 vertex) {
    f_bdc8ba8c(vertex);
    f_70211597();
    finalize();
}

void f_222d564b(inout vec4 vertex) {
    f_bdc8ba8c(vertex);
    f_a298389e();
    f_ae8b8804();
    finalize();
}

void f_0dfb7042(inout vec4 vertex) {
    f_bdc8ba8c(vertex);
    f_ae8b8804();
    f_70211597();
    finalize();
}

void f_592b6346(inout vec4 vertex) {
    f_a298389e();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_bdc8ba8c(vertex);
    finalize();
}

void f_17975ef4(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_70211597();
    f_bdc8ba8c(vertex);
    finalize();
}

void f_9866d19d(inout vec4 vertex, float speed) {
    f_bdc8ba8c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_52b26591(inout vec4 vertex) {
    f_bdc8ba8c(vertex);
    f_a298389e();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_eae0bc66(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_a298389e();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_bdc8ba8c(vertex);
            f_a298389e();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_222d564b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_222d564b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_592b6346(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_592b6346(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_9866d19d(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_52b26591(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_d51aec5f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_222d564b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_0dfb7042(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_592b6346(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_17975ef4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_9866d19d(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_d51aec5f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_222d564b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_0dfb7042(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_592b6346(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_17975ef4(vertex);
        return;
    }
    

    
    f_bdc8ba8c(vertex);
    f_a298389e();
    finalize();
}