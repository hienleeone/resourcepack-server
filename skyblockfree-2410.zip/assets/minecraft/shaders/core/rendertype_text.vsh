#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_c6ff0b30(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e73541d8() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_69579ede(inout vec4 vertex) {
    f_c6ff0b30(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e73541d8();
    }
    finalize();
}



void f_997780a6() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_e00a9baa() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_045c5913(inout vec4 vertex) {
    f_c6ff0b30(vertex);
    f_997780a6();
    finalize();
}

void f_6e15adb1(inout vec4 vertex) {
    f_c6ff0b30(vertex);
    f_e73541d8();
    f_e00a9baa();
    finalize();
}

void f_87043dfc(inout vec4 vertex) {
    f_c6ff0b30(vertex);
    f_e00a9baa();
    f_997780a6();
    finalize();
}

void f_d03b9b2a(inout vec4 vertex) {
    f_e73541d8();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_c6ff0b30(vertex);
    finalize();
}

void f_5aa5da0c(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_997780a6();
    f_c6ff0b30(vertex);
    finalize();
}

void f_dd2bac87(inout vec4 vertex, float speed) {
    f_c6ff0b30(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_59ec4cfb(inout vec4 vertex) {
    f_c6ff0b30(vertex);
    f_e73541d8();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_69579ede(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e73541d8();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_c6ff0b30(vertex);
            f_e73541d8();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_6e15adb1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_6e15adb1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_d03b9b2a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_d03b9b2a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_dd2bac87(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_59ec4cfb(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_045c5913(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_6e15adb1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_87043dfc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_d03b9b2a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5aa5da0c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_dd2bac87(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_045c5913(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_6e15adb1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_87043dfc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_d03b9b2a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5aa5da0c(vertex);
        return;
    }
    

    
    f_c6ff0b30(vertex);
    f_e73541d8();
    finalize();
}